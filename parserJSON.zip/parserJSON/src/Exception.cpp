/*
 * Exception.cpp
 *
 *  Created on: 2017. 4. 6.
 *      Author: choi.sungwoon
 */

#include "Exception.h"

Message gMessage;


